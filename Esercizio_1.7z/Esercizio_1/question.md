Crea una pagina con un articolo per un blog.
 - La pagina dovrà contenere l'articolo e un footer con un form di sottoscrizione al blog. 
 - L'articolo si compone di titolo, testo e immagini in fondo.
 - Il form dovrà comporsi di un campo obbligatorio per l'inserimento della mail e un pulsante di invio. 

 
Usa quanto più possibile i tag semantici.